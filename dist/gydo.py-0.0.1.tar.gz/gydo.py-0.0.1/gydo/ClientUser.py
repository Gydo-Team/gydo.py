class ClientUser:
    def __init__(self, data):
        self.id = None 
        
        self.discriminator = None 
        
        self.username = None
    
        self.tag = None